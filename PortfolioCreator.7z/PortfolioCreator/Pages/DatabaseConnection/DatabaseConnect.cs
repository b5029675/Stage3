﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PortfolioCreator.Pages.DatabaseConnection
{
    public class DatabaseConnect
    {
        public string DatabaseString()
        {
            string DbString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Matt\source\repos\Stage3-main\PortfolioCreator\PortfolioCreator\Database\PortfolioCreator.mdf;Integrated Security=True;Connect Timeout=30";
            return DbString;
        }
    }
}
