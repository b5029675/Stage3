using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PortfolioCreator.Models;
using PortfolioCreator.Pages.DatabaseConnection;

namespace PortfolioCreator.Pages.Login
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        public Student Student { get; set; }

        public string Message { get; set; }

        public string SessionID;
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            DatabaseConnect dbstring = new DatabaseConnect(); //creating an object from the class
            string DbConnection = dbstring.DatabaseString(); //calling the method from the class
            Console.WriteLine(DbConnection);
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Student.StudentNo);
            Console.WriteLine(Student.StudentPassword);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT StudentNo, StudentName, Role FROM Student WHERE StudentNo = @SNo AND StudentPassword = @SPass";

                command.Parameters.AddWithValue("@SNo", Student.StudentNo);
                command.Parameters.AddWithValue("@SPass", Student.StudentPassword);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Student.StudentNo = reader.GetString(0);
                    Student.StudentName = reader.GetString(1);
                    Student.Role = reader.GetString(2);
                }
            }

            if (!string.IsNullOrEmpty(Student.StudentName))
            {
                SessionID = HttpContext.Session.Id;
                HttpContext.Session.SetString("sessionID", SessionID);
                HttpContext.Session.SetString("studentno", Student.StudentNo);
                HttpContext.Session.SetString("fname", Student.StudentName);

                if (Student.Role == "User")
                {
                    return RedirectToPage("/UserPages/UserIndex");
                }
                else
                {
                    return RedirectToPage("/AdminPages/AdminIndex");
                }


            }
            else
            {
                Message = "Invalid Username and Password!";
                return Page();
            }

        }
    }
}
