﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PortfolioCreator.Models
{
    public class Student
    {
        public int Id { get; set; }
        [Display(Name ="Student Number")]
        public string StudentNo { get; set; }
        [Display(Name="First Name")]
        public string StudentName { get; set; }
        [Display(Name = "Surname")]
        public string StudentLName { get; set; }
        [Display(Name = "Course")]
        public string StudentCourse { get; set; }
        [Display(Name = "Password")]
        public string StudentPassword { get; set; }
        public string Role { get; set; }

    }
}
