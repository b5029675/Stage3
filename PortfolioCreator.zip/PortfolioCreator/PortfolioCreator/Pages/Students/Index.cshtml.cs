using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PortfolioCreator.Models;

namespace PortfolioCreator.Pages.Students
{
    [BindProperties]
    public class IndexModel : PageModel
    {
        public Student StudentRec { get; set; }

        public List<string> SRole { get; set; } = new List<string> { "User", "Admin" };
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=PortfolioCreator;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Student (StudentNo, StudentName, StudentLName, StudentCourse, StudentPassword, Role) VALUES (@SNo, @SName, @SLName, @SCourse, @SPass, @SRole)";

                command.Parameters.AddWithValue("@SNo", StudentRec.StudentNo);
                command.Parameters.AddWithValue("@SName", StudentRec.StudentName);
                command.Parameters.AddWithValue("@SLName", StudentRec.StudentLName);
                command.Parameters.AddWithValue("@SCourse", StudentRec.StudentCourse);
                command.Parameters.AddWithValue("@SPass", StudentRec.StudentPassword);
                command.Parameters.AddWithValue("@SRole", StudentRec.Role);

                Console.WriteLine(StudentRec.StudentNo);
                Console.WriteLine(StudentRec.StudentName);
                Console.WriteLine(StudentRec.StudentLName);
                Console.WriteLine(StudentRec.StudentCourse);
                Console.WriteLine(StudentRec.StudentPassword);
                Console.WriteLine(StudentRec.Role);


                command.ExecuteNonQuery();
            }


            return RedirectToPage("/Index");
        }
    }
}
